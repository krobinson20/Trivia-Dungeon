<html>
<head><title>thank you</title></head>
<body>
<?php
//phpinfo(); 
$myfile = fopen("users.txt","w") or die("unable to open file");
$writename = $_POST["name"];
$writeEmail= $_POST["email"];
fwrite($myfile,$writename);
fwrite($myfile,$writeEmail);
fclose($myfile);

?>
Thank you for your submission <?php echo $_POST['name']; ?>
</body>
</html>